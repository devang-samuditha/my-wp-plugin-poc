<?php
/*
Plugin Name: Tetrinest POC
Description: Proof-of-concept for self-hosted plugin auto-update.
Version: 1.0.0
Author: Tetrinest
Update URI: https://raw.githubusercontent.com/devang-samuditha/my-wp-plugin-poc/main/tetrinest-poc
*/

if (!defined('ABSPATH')) exit; // direct access se bacho

// update.json ka raw URL — apna devang-samuditha/my-wp-plugin-poc daalo
define('TETRINEST_POC_UPDATE_JSON', 'https://raw.githubusercontent.com/devang-samuditha/my-wp-plugin-poc/main/update.json');

/**
 * WordPress ke update-check ke beech mein aake apni host se version poochta hai.
 * Hook ka naam Update URI ke HOSTNAME se banta hai (path nahi) → raw.githubusercontent.com
 */
add_filter('update_plugins_raw.githubusercontent.com', function ($update, $plugin_data, $plugin_file) {
    // Sirf HAMARE plugin ke liye chale, us host ke doosre plugins ke liye nahi
    if (($plugin_data['UpdateURI'] ?? '') !== 'https://raw.githubusercontent.com/devang-samuditha/my-wp-plugin-poc/main/tetrinest-poc') {
        return $update;
    }

    $res = wp_remote_get(TETRINEST_POC_UPDATE_JSON, ['timeout' => 15]);
    if (is_wp_error($res)) return $update;

    $info = json_decode(wp_remote_retrieve_body($res), true);
    if (empty($info['version']) || empty($info['download_url'])) return $update;

    $current = $plugin_data['Version']; // abhi installed version, header se

    if (version_compare($info['version'], $current, '>')) {
        return [
            'slug'    => 'tetrinest-poc',
            'version' => $info['version'],
            'package' => $info['download_url'],
        ];
    }
    return $update;
}, 10, 3);
