<?php
/*
Plugin Name: Tetrinest POC
Description: Proof-of-concept for self-hosted plugin auto-update.
Version: 1.2.0
Author: Tetrinest
Update URI: https://raw.githubusercontent.com/devang-samuditha/my-wp-plugin-poc/main/tetrinest-poc
*/

if (!defined('ABSPATH')) exit;

define('TETRINEST_POC_UPDATE_JSON', 'https://raw.githubusercontent.com/devang-samuditha/my-wp-plugin-poc/main/update.json');

/**
 * Server se update.json fetch karke [version, download_url] laata hai. Fail par null.
 */
function tetrinest_poc_fetch_remote() {
    $res = wp_remote_get(TETRINEST_POC_UPDATE_JSON, ['timeout' => 15]);
    if (is_wp_error($res)) return null;
    $info = json_decode(wp_remote_retrieve_body($res), true);
    if (empty($info['version']) || empty($info['download_url'])) return null;
    return $info;
}

/**
 * CLASSIC mechanism: WordPress jab bhi update-list transient set karta hai,
 * ham beech mein aake apna plugin uski response mein daal dete hain.
 * Ye har WP version par reliably chalta hai (Update URI header par depend nahi).
 */
add_filter('pre_set_site_transient_update_plugins', function ($transient) {
    if (empty($transient) || empty($transient->checked)) return $transient;

    $info = tetrinest_poc_fetch_remote();
    if (!$info) return $transient;

    $plugin_file = plugin_basename(__FILE__);              // tetrinest-poc/tetrinest-poc.php
    $current     = $transient->checked[$plugin_file] ?? '0';

    if (version_compare($info['version'], $current, '>')) {
        $transient->response[$plugin_file] = (object) [
            'id'          => $plugin_file,
            'slug'        => 'tetrinest-poc',
            'plugin'      => $plugin_file,
            'new_version' => $info['version'],
            'url'         => 'https://github.com/devang-samuditha/my-wp-plugin-poc',
            'package'     => $info['download_url'],
        ];
    }
    return $transient;
});

/**
 * DEBUG NOTICE: admin ke har page par ek dabba dikhata hai jisme pata chalta hai
 * ki plugin server se kya dekh raha hai. POC verify hone ke baad ye hata dena.
 */
add_action('admin_notices', function () {
    $info = tetrinest_poc_fetch_remote();
    $installed = get_file_data(__FILE__, ['Version' => 'Version'])['Version'];

    echo '<div class="notice notice-info"><p><strong>Tetrinest POC debug:</strong> ';
    if (!$info) {
        echo 'server se update.json FETCH NAHI HUA (network/URL issue).';
    } else {
        $needs = version_compare($info['version'], $installed, '>') ? 'YES' : 'no';
        echo "installed = <code>{$installed}</code> &nbsp;|&nbsp; server = <code>{$info['version']}</code> &nbsp;|&nbsp; update needed = <strong>{$needs}</strong>";
    }
    echo '</p></div>';
});
